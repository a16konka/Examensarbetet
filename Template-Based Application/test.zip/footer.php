


		<div class="footer-container">
			<footer class="wrapper">
			  <p class="footer-credits">© 2019 Online Bokkatalog</p>
			  <p>All trademarks and registered trademarks appearing on this site are the property of their respective owners.</p>
			</footer>
		</div>
    	<?php wp_footer();?>
	</body>
</html>